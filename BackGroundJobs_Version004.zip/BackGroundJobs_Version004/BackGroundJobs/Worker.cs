using NetCoreAudio;

namespace BackGroundJobs
{
    public class Worker : BackgroundService
    {
        private readonly ILogger<Worker> _logger;
        private IConfiguration configuration;
        public Worker(ILogger<Worker> logger,IConfiguration iConfig)
        {
            _logger = logger;
            configuration = iConfig;
        }

        protected override async Task ExecuteAsync(CancellationToken stoppingToken)
        {
            while (!stoppingToken.IsCancellationRequested)
            {
                string sJobTimerInMinutes = configuration.GetValue<string>("JobTimerInMinutes");
                Int32 lJobTimerInMinutes = 60000 * Convert.ToInt32(sJobTimerInMinutes);
                Console.WriteLine("Worker running at :" + DateTime.Now.ToString());
                WaslListenerJob.SearchAvailableInventory(configuration, _logger);
                await Task.Delay(lJobTimerInMinutes, stoppingToken);
            }
        }




    }
}