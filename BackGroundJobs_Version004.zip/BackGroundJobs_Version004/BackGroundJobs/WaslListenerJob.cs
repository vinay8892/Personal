﻿using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;
using BackGroundJobs.Models;
using System.Net.Http.Json;
using System.IO;
using Newtonsoft.Json.Linq;
using System.Net.Http.Headers;
using NetCoreAudio;
using Microsoft.Extensions.Logging;

namespace BackGroundJobs
{
    internal static class WaslListenerJob
    {
      
        public static async void PlayMusic()
        {
            //string fileName = @"D:\\ringtone_30_secs.mp3";
            string fileName = "Files/ringtone_30_secs.mp3";
            var player = new Player();
            player.PlaybackFinished += OnPlaybackFinished;
            player.Play(fileName).Wait();

        }

        private static void OnPlaybackFinished(object sender, EventArgs e)
        {
            Console.WriteLine("Playback finished");
        }

        public static async void SearchAvailableInventory(IConfiguration configuration, ILogger<Worker> logger)
        {
            string sWASLAPI = configuration.GetValue<string>("WASLAPI");
            string sSearchKeyword = configuration.GetValue<string>("SearchKeyword");
            try
            {
                using (var httpClient = new HttpClient())
                {
                    var response = await httpClient.GetAsync(sWASLAPI);
                    if (response.IsSuccessStatusCode)
                    {
                        var strjson = await response.Content.ReadAsStringAsync();
                        if (strjson.ToLower().Contains(sSearchKeyword.ToLower()))
                        {
                            PlayMusic();
                            logger.LogInformation("********Found the inventory***********Response:");
                            logger.LogInformation(strjson);
                        }
                    }
                }
            }
            catch(Exception ex)
            {
                logger.LogError(ex.Message);
            }          

        }

    }
}
