﻿
namespace CRM.ApiModels
{
    public class FCMTokenData
    {
        public string deviceToken { get; set; }
        public string tokenDate { get; set; }
    }
}