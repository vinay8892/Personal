﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using CRM.Models;

namespace CRM.ApiModels
{
    public class LoginResponse
    {
        public int success { get; set; }
        public string role { get; set; }

    }

    public class MobileApiMasters
    {
        public List<User> users { get; set; }
        public List<Project> projects { get; set; }
        public List<LeadSource> leadSources { get; set; }
    }

    public class SendToCRMRequest
    {
        public string keyReference { get; set; }
        public string name { get; set; }
        public string email { get; set; }
        public string mobile { get; set; }
        public string project { get; set; }
        public string comment { get; set; }
        public string user { get; set; }
    }

    public class SendToCRMResponse
    {
        public int success { get; set; }
        public string message { get; set; }
    }

    public class RemoveLeadRequest
    {
        public string keyReference { get; set; }
        public string comment { get; set; }
        public string user { get; set; }
    }

}
