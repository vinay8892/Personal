﻿namespace CRM.ApiModels
{
    public class LeadRequest
    {
        public string name { get; set; }

        public string mobile { get; set; }

        public string email { get; set; }

        public string date { get; set; }

        public string projectName { get; set; }
        public string otpText { get; set; }
        public string otpReference { get; set; }
    }
}
