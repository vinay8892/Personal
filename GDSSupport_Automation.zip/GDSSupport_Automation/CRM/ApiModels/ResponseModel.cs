﻿using Newtonsoft.Json;

namespace CRM.ApiModels
{
    public class ResponseModel
    {
        [JsonProperty("isSuccess")]
        public bool IsSuccess { get; set; }
        [JsonProperty("message")]
        public string Message { get; set; }
    }

    public class OtpResponse
    {
        [JsonProperty("isSuccess")]
        public bool IsSuccess { get; set; }
        [JsonProperty("otpText")]
        public string OtpText { get; set; }
        [JsonProperty("referenceId")]
        public string ReferenceId { get; set; }
        [JsonProperty("message")]
        public string Message { get; set; }
    }

    public class AuthenticateClientResponse
    {
        [JsonProperty("isSuccess")]
        public bool IsSuccess { get; set; }
        [JsonProperty("adminPanelContent")]
        public string AdminPanelContent { get; set; }
    }
}
