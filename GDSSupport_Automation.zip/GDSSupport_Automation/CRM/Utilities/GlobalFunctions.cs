﻿using System;
using System.Linq;
using CRM.Data;
using CRM.Models;
using CRM.ViewModels;
using Microsoft.EntityFrameworkCore;

namespace CRM.Utilities
{
    public static class GlobalFunctions
    {
        public static string CRMSettingValue(CRMContext context,string settingKeyword)
        {
            var CRMSetting= context.CRMSettings.Where(x =>x.settingKeyword== settingKeyword);
            string settingvalue = string.Empty;
            if(CRMSetting!=null)
            {
                settingvalue= CRMSetting.Select(x => x.settingValue).FirstOrDefault();  
            }
            return settingvalue;    
        }

        public static string GetERPChannelName(string channelId)
        {          
            string channelName = string.Empty;
            if(Convert.ToInt32(channelId)==(int)ERPChannelsEnum.WebERP)
            {
                channelName = "Web ERP";
            }
            else if(Convert.ToInt32(channelId) == (int)ERPChannelsEnum.MobileERP)
            {
                channelName = "Mobile ERP";
            }
            return channelName;
        }

        public static bool SaveHistory(CRMContext context, string channelId,string historyAction,string customerId,string userId,string description)
        {
            CustomerActionHistory customerHist = new CustomerActionHistory();
            customerHist.CRMChannel = Convert.ToString(channelId);
            customerHist.histDate = DateTime.Now.ToString();
            customerHist.histAction = historyAction;
            customerHist.customerId = customerId;
            customerHist.userId = userId;
            customerHist.description = description;

            context.CustomerActionHistory.Add(customerHist);
            context.SaveChangesAsync();
            return true;
        }

        public static bool SaveComments(CRMContext context, string CommentText, string customerId, string channelId, string userId)
        {
            if(!string.IsNullOrEmpty(CommentText))
            {
                CustomerComment comment = new CustomerComment();
                comment.commentText = CommentText;
                comment.customerId = customerId;
                comment.commentDate = DateTime.Now.ToString();
                comment.commentChannel = channelId;
                comment.commentedBy = userId;

                context.CustomerComments.Add(comment);
                context.SaveChangesAsync();
            }
            return true;
        }

        public static Customer CloneCustomer(WebLeadsEditViewModel webLeadsEditViewModel)
        {
            Customer custClone=new Customer();
            custClone.Id = webLeadsEditViewModel.Id;
            custClone.leadCreationDate = webLeadsEditViewModel.leadCreationDate;
            custClone.customerId = webLeadsEditViewModel.customerId;
            custClone.lastUpdateToken = DateTime.Now.ToString("yyyy-MM-ddTHH:mm:ss");
            custClone.name = webLeadsEditViewModel.name;
            custClone.emailId = webLeadsEditViewModel.emailId;
            custClone.followupDate = webLeadsEditViewModel.followupDate;
            custClone.leadSourceCode = webLeadsEditViewModel.leadSourceCode;
            custClone.leadStatus = webLeadsEditViewModel.leadStatus;
            custClone.mobile = webLeadsEditViewModel.mobile;
            custClone.projectCode = webLeadsEditViewModel.projectCode;
            return custClone;
        }
        public static string HistoryDescriptionOnEdit(Customer OriginalCustomer,Customer EdittedCustomer,DbSet<User> users)
        {
            string strDefaultHistoryText = "No Updation on lead";
            string strHistoryText = "";
            if (OriginalCustomer.name!= EdittedCustomer.name)
            {
                strHistoryText = "Name changed from " + OriginalCustomer.name + " to " + EdittedCustomer.name + ". ";
            }
            if (OriginalCustomer.mobile != EdittedCustomer.mobile)
            {
                strHistoryText = strHistoryText + "Mobile changed from " + OriginalCustomer.mobile + " to " + EdittedCustomer.mobile + ". ";
            }
            if (OriginalCustomer.emailId != EdittedCustomer.emailId)
            {
                strHistoryText = strHistoryText + "Email changed from " + OriginalCustomer.emailId + " to " + EdittedCustomer.emailId + ". ";
            }
            if (OriginalCustomer.followupDate != EdittedCustomer.followupDate)
            {
                strHistoryText = strHistoryText + "Follow Up Date changed from " + OriginalCustomer.followupDate + " to " + EdittedCustomer.followupDate + ". ";
            }
            if (OriginalCustomer.assignedTo != EdittedCustomer.assignedTo)
            {
                string OriginalAssignedToUser="";
                string EdittedAssignedToUser = "";
                if (!string.IsNullOrWhiteSpace(OriginalCustomer.assignedTo))
                {
                    OriginalAssignedToUser = users.FirstOrDefaultAsync(m => m.Id.ToString() == OriginalCustomer.assignedTo).Result.Name;
                }
                if (!string.IsNullOrWhiteSpace(EdittedCustomer.assignedTo))
                {
                    EdittedAssignedToUser = users.FirstOrDefaultAsync(m => m.Id.ToString() == EdittedCustomer.assignedTo).Result.Name;
                }
                strHistoryText = strHistoryText + "Assigned this lead from " + OriginalAssignedToUser + " to " + EdittedAssignedToUser + " user. ";
            }
            if (OriginalCustomer.leadSourceCode != EdittedCustomer.leadSourceCode)
            {
                strHistoryText = strHistoryText + "Lead Source Code changed from " + OriginalCustomer.leadSourceCode + " to " + EdittedCustomer.leadSourceCode + ". ";
            }
            if (OriginalCustomer.leadStatus != EdittedCustomer.leadStatus)
            {
                strHistoryText = strHistoryText + "Lead status changed from " + HtmlHelperExtensions.GetLeadStatus(Convert.ToInt32(OriginalCustomer.leadStatus)) + " to " + HtmlHelperExtensions.GetLeadStatus(Convert.ToInt32(EdittedCustomer.leadStatus)) + ". ";
            }
            if (OriginalCustomer.projectCode != EdittedCustomer.projectCode)
            {
                strHistoryText = strHistoryText + "Project Code changed from " + OriginalCustomer.projectCode + " to " + EdittedCustomer.projectCode + ". ";
            }
            if (string.IsNullOrWhiteSpace(strHistoryText))
            {
                strHistoryText = strDefaultHistoryText;
            }
            return strHistoryText;
        }

    }
}
