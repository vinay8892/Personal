﻿
using System.Collections.Generic;

namespace CRM.ViewModels
{
    public class WebLeadsViewModel
    {
        public string keyReference { get; set; }
        public string name { get; set; }
        public string mobile { get; set; }
        public string email { get; set; }
        public string date { get; set; }
        public string projectName { get; set; }
        public string otpText { get; set; }
        public string otpReference { get; set; }
        public string deleteComment { get; set; }
    }

    public class selectedLeads
    {
        public List<string> leads { get; set; }
        public string deleteComment { get; set; }
    }

}
