﻿using CRM.Models;
using System.ComponentModel.DataAnnotations;
using System;
using AutoMapper;
using System.Collections.Generic;

namespace CRM.ViewModels
{
    public class AssignLeadViewModel :Customer
    {
        public bool isChecked { get; set; }
    }

    public class AssignLeadObjectFromView 
    {
        public string assignFrom { get; set; }
        public string assignTo { get; set; }
        public string shareHistory { get; set; }
        public string shareComments { get; set; }
        public List<string> customerIds { get; set; }
    }

    public class LeadProfile : Profile
    {
        public LeadProfile()
        {
            CreateMap<Customer, AssignLeadViewModel>();
            CreateMap<AssignLeadViewModel, Customer>();
        }
    }

}
