﻿using CRM.Models;

namespace CRM.ViewModels
{
    public class WebLeadsEditViewModel : Customer
    {
        public string Comment { get; set; }
        public string keyReference { get; set; }
    }

}
