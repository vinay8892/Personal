﻿using CRM.Models;

namespace CRM.ViewModels
{
    public class ProjectViewModel : Project
    {
        public bool IsUsedInTransaction { get; set; }
    }

}
