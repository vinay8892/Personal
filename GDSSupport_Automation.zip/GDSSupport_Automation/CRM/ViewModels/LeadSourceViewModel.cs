﻿using CRM.Models;

namespace CRM.ViewModels
{
    public class LeadSourceViewModel : LeadSource
    {
        public bool IsUsedInTransaction { get; set; }
    }

}
