namespace CRM.Models
{
    public enum LeadStatusEnum
    {
        NewLead = 0,
        Interested = 1,
        NotInterested = 2,
        FollowUp = 3,
        WrongLead = 4,
        Closed = 5
    }

    public enum ERPChannelsEnum
    {
        WebERP = 1,
        MobileERP = 2
    }

    public static class HistoryActions
    {
        public static readonly string NewLead = "New Lead";
        public static readonly string UpdateLead = "Lead Updation";
    }


}
