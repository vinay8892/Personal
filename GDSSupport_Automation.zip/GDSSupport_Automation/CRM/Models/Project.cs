﻿using System;
using System.ComponentModel.DataAnnotations;

namespace CRM.Models
{
    public class Project
    {
        [Key]
        public string projectCode { get; set; }

        [StringLength(60, MinimumLength = 2)]
        [Required(ErrorMessage = "Please Enter the Project Name")]
        public string projectName { get; set; }

        [StringLength(60, MinimumLength = 2)]
        [Required(ErrorMessage = "Please Enter the Project Location")]
        public string projectLocation { get; set; }
    }
}
