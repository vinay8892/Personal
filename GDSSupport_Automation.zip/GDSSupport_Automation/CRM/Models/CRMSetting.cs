﻿
namespace CRM.Models
{
    public class CRMSetting
    {
        public int Id { get; set; }
        public string settingKeyword { get; set; }
        public string settingValue { get; set; }
        public string description { get; set; }
        public string sectionId { get; set; }
        public string dataType { get; set; }
        public string displayLabel { get; set; }

    }

}
