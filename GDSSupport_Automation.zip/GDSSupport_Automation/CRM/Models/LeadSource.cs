﻿using System;
using System.ComponentModel.DataAnnotations;

namespace CRM.Models
{
    public class LeadSource
    {
        [Key]
        public string leadSourceCode { get; set; }

        [StringLength(60, MinimumLength = 2)]
        [Required(ErrorMessage = "Please Enter the lead Source Name")]
        public string leadSourceName { get; set; }
    }
}
