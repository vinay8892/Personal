using System.Diagnostics;

namespace CRM.Models
{
    public static class HtmlHelperExtensions
    {
        public static string GetLeadStatus(int leadstatus)
        {
            var leaddisplaystatus = (LeadStatusEnum)leadstatus;
            return leaddisplaystatus.ToString();
        }

        public static void PlaySound(string file)
        {
            Process.Start(@"powershell", $@"-c (New-Object Media.SoundPlayer '{file}').PlaySync();");
        }
    }
}
