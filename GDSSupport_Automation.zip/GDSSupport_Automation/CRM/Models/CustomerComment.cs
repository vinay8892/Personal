﻿using System;
using System.ComponentModel.DataAnnotations;

namespace CRM.Models
{
    public class CustomerComment
    {
        public int Id { get; set; }

        [StringLength(60, MinimumLength = 2)]
        [Required(ErrorMessage = "Please Enter customer Id")]
        public string customerId { get; set; }

        [StringLength(500, MinimumLength = 2)]
        [Required(ErrorMessage = "Please Enter comment Text")]
        public string commentText { get; set; }

        [StringLength(60, MinimumLength = 2)]
        [Required(ErrorMessage = "Please Enter comment Date")]
        public string commentDate { get; set; }

        [StringLength(15, MinimumLength = 2)]
        [Required(ErrorMessage = "Please Enter comment channel")]
        public string commentChannel { get; set; }

        [StringLength(15, MinimumLength = 2)]
        [Required(ErrorMessage = "Please Enter commented by")]
        public string commentedBy { get; set; }
    }
}
