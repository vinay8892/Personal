﻿
namespace CRM.Models
{
    public class DeletedWebLeads
    {
        public int Id { get; set; }
        public string keyReference { get; set; }
        public string name { get; set; }
        public string mobile { get; set; }
        public string email { get; set; }
        public string date { get; set; }
        public string projectName { get; set; }
        public string deleteComment { get; set; }
        public string deletedBy { get; set; }
        public string deletedDate { get; set; }

    }

}
