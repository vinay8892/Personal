﻿using System;
using System.ComponentModel.DataAnnotations;

namespace CRM.Models
{
    public class CustomerActionHistory
    {
        public int Id { get; set; }
        public string histDate { get; set; }
        public string histAction { get; set; }
        public string description { get; set; }
        public string customerId { get; set; }
        public string userId { get; set; }
        public string CRMChannel { get; set; }
    }
}
