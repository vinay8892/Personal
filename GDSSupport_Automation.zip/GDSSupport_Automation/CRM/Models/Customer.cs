﻿using System;
using System.ComponentModel.DataAnnotations;

namespace CRM.Models
{
    public class Customer
    {
        public int Id { get; set; }
        public string customerId { get; set; }

        [StringLength(60, MinimumLength = 2)]
        [Required(ErrorMessage = "Please Enter Name")]
        public string name { get; set; }

        //[RegularExpression(@"^(\d{9})$", ErrorMessage = "Please Enter Right Phone Number")]
        [Required(ErrorMessage = "Please Enter Phone Number")]
        public string mobile { get; set; }

        //[RegularExpression(@"^(([^<>()[\]\\.,;:\s@""]+(\.[^<>()[\]\\.,;:\s@""]+)*)|("".+""))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$", ErrorMessage = "Please Enter Right Email")]
        //[Required(ErrorMessage = "Please Enter Email")]
        public string emailId { get; set; }

        [Required(ErrorMessage = "Please select Project name")]
        public string projectCode { get; set; }
        [Required(ErrorMessage = "Please select lead source")]
        public string leadSourceCode { get; set; }

        [Required(ErrorMessage = "Please select lead status")]
        public string leadStatus { get; set; }
        public DateTime leadCreationDate { get; set; }
        //[DataType(DataType.DateTime)]
        //[Required(ErrorMessage = "Please Enter Date Of Followup")]
        public DateTime followupDate { get; set; }
        public string lastUpdateToken { get; set; }
        public string lastModifiedBy { get; set; }
        public string assignedTo { get; set; }
        public string shareHistory { get; set; }
        public string shareComments { get; set; }

    }
}
