using Microsoft.EntityFrameworkCore;
using CRM.Models;

namespace CRM.Data
{
    public class CRMContext : DbContext
    {
        public CRMContext(DbContextOptions<CRMContext> options)
            : base(options)
        {
        }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            //modelBuilder.Entity<LeadSource>().HasNoKey();
        }

        public DbSet<User> User { get; set; }
        public DbSet<CRM.Models.Role> Role { get; set; }
        public DbSet<CRM.Models.Business> Business { get; set; }
        public DbSet<CRM.Models.Company> Company { get; set; }
        public DbSet<CRM.Models.Note> Note { get; set; }
        public DbSet<CRM.Models.Contact> Contact { get; set; }
        public DbSet<CRM.Models.LeadSource> LeadSource { get; set; }
        public DbSet<CRM.Models.Project> Project { get; set; }
        public DbSet<CRM.Models.Customer> Customers { get; set; }
        public DbSet<CRM.Models.DeletedWebLeads> DeletedWebLeads { get; set; }
        public DbSet<CRM.Models.CustomerComment> CustomerComments { get; set; }
        public DbSet<CRM.Models.CustomerActionHistory> CustomerActionHistory { get; set; }
        public DbSet<CRM.Models.CRMSetting> CRMSettings { get; set; }

    }
}