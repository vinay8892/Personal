﻿// Please see documentation at https://docs.microsoft.com/aspnet/core/client-side/bundling-and-minification
// for details on configuring this project to bundle and minify static web assets.

// Write your JavaScript code.
$(document).ready(function () {

    var Status = null;
    var result = [];
    var customers = [];

    $('#btnAssign').click(function () {
        $("#tblCustomers TBODY TR").each(function () {
            var rowObj = $(this);
            if (rowObj.find('input[type=checkbox]:checked').val() != undefined) {
                customers.push(rowObj.find("TD").eq(8).html().trim());
            }           
        });


        console.log(customers);
        var assignLeadObj = {
            assignFrom: $('#filter').val(),
            assignTo: $('#AssignTo').val(),
            shareHistory: $('input[name="chkShareHistory"]:checked').val(),
            shareComments: $('input[name="chkShareComments"]:checked').val(),
            customerIds: customers
        };
      
        console.log(assignLeadObj);

        $.ajax({
            type: "POST",
            url: "/AssignLeads/AssignCustomers",
            data: assignLeadObj,
            success: function (data) {
                alert('Saved Successfully');
            }
        });

        customers = [];
    });

    $('#btnDeleteSelected').click(function () {
        var leads = [];
        $("#tblleads TBODY TR").each(function () {
            var rowObj = $(this);
            if (rowObj.find('input[type=checkbox]:checked').val() != undefined) {
                leads.push(rowObj.find("TD").eq(6).html().trim());
            }
        });
        if (leads.length == 0) {
            alert('No Any lead selected. Please select at least one lead');
            return
        }
        console.log(leads);
        var leadsObj = {
            leads: leads,
            deleteComment: $('#webleadDeleteComment').val()
        };

        console.log(leadsObj);

        $.ajax({
            type: "POST",
            url: "/WebLeads/DeleteSelected",
            data: leadsObj,
            success: function (data) {
                alert('Saved Successfully');
            }
        });

        leads = [];
    });

    $('#btnSendToCRMSelected').click(function () {
        var leads = [];
        $("#tblleads TBODY TR").each(function () {
            var rowObj = $(this);
            if (rowObj.find('input[type=checkbox]:checked').val() != undefined) {
                leads.push(rowObj.find("TD").eq(6).html().trim());
            }
        });
        if (leads.length == 0) {
            alert('No Any lead selected. Please select at least one lead');
            return
        }
        console.log(leads);
        var leadsObj = {
            leads: leads,
            deleteComment: $('#webleadDeleteComment').val()
        };

        console.log(leadsObj);

        $.ajax({
            type: "POST",
            url: "/WebLeads/SendToCRMSelectedLeads",
            data: leadsObj,
            success: function (data) {
                alert('Saved Successfully');
            }
        });

        leads = [];
    });


});

