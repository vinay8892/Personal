using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using CRM.Data;
using CRM.Models;
using Microsoft.AspNetCore.Authorization;
using CRM.ViewModels;
using AutoMapper;
using CRM.BusinessLayer;
using System;
using CRM.Utilities;

namespace CRM.Controllers
{
    public class AssignLeadsController : Controller
    {
        private readonly CRMContext _context;
        private readonly IMapper _mapper;
        public AssignLeadsController(CRMContext context, IMapper mapper)
        {
            _context = context;
            _mapper = mapper;
        }

        // GET: Contacts
        [Authorize]
        public async Task<IActionResult> Index(string filter)
        {
            var user = await _context.User.FirstOrDefaultAsync(m => m.Login == User.FindFirst("user").Value);
            ViewBag.userId = user.Id;
            List<Project> projectsList = _context.Project.ToList();
            ViewData["projects"] = projectsList;
            List<User> usersList = _context.User.ToList();
            ViewBag.users = usersList;
            List<LeadSource> leadSourceList = _context.LeadSource.ToList();
            ViewData["leadSources"] = leadSourceList;
            var qry = _context.Customers.AsNoTracking().OrderByDescending(p => p.Id).AsQueryable();
            if (filter == "-1")
            {
                filter = null;
            }
            if (!string.IsNullOrWhiteSpace(filter))
            {
                qry = qry.Where(p => p.assignedTo.ToUpper().Contains(filter.ToUpper()));
            }
            else
            {
                qry = qry.Where(p => p.assignedTo.Equals(filter));
            }
            var model = await qry.ToListAsync();
            List<AssignLeadViewModel> modelNew = new List<AssignLeadViewModel>();

            foreach (Customer item in model)
            {
                var assignLeadViewModel = _mapper.Map<AssignLeadViewModel>(item);
                assignLeadViewModel.isChecked = false;
                modelNew.Add(assignLeadViewModel);
            }
            ViewBag.filter = filter;
            List<User> users = _context.User.ToList();
            ViewBag.users = users;
            return View(modelNew);
        }

        [HttpPost]
        public string AssignCustomers(AssignLeadObjectFromView assignLeadFromView)
        {
            foreach(string custId in assignLeadFromView.customerIds)
            {
                int channelId = (int)ERPChannelsEnum.WebERP;
                var user =  _context.User.FirstOrDefaultAsync(m => m.Login == User.FindFirst("user").Value);
                var customer = _context.Customers.Where(p => p.customerId == custId).FirstOrDefault();
                if (customer!=null)
                {
                    customer.assignedTo = assignLeadFromView.assignTo;
                    customer.shareHistory = string.IsNullOrWhiteSpace(assignLeadFromView.shareHistory) ? "0" : "1";
                    customer.shareComments = string.IsNullOrWhiteSpace(assignLeadFromView.shareComments) ? "0" : "1";
                    _context.Update(customer);
                    _context.SaveChangesAsync();
                    GlobalFunctions.SaveHistory(_context, Convert.ToString(channelId), HistoryActions.UpdateLead,
                    customer.customerId, Convert.ToString(user.Result.Id), "This Customer Lead has been assigned to User :" + user.Result.Name);
                }
            }
            _context.SaveChanges();
            return "success";
        }
    }
}
