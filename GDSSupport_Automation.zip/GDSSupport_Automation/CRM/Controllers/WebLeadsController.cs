using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using CRM.Data;
using CRM.Models;
using Microsoft.AspNetCore.Authorization;
using CRM.BusinessLayer;
using CRM.ViewModels;
using Microsoft.CodeAnalysis.Operations;
using CRM.Utilities;
using System.Security.Cryptography.Xml;
using System.Globalization;

namespace CRM.Controllers
{
    public class WebLeadsController : Controller
    {
        private readonly CRMContext _context;

        public WebLeadsController(CRMContext context)
        {
            _context = context;
        }

        // GET: Business
        [Authorize]
        public async Task<IActionResult> Index()
        {
            DatabaseClient firebaseDbBusiness = new DatabaseClient();

            var LeadData = await firebaseDbBusiness.GetStudents();

            return View(LeadData.ToList());
        }

        //// GET: Business/Create
        public IActionResult Create()
        {
            return View();
        }

        //// POST: Business/Create
        //// To protect from overposting attacks, enable the specific properties you want to bind to, for 
        //// more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(WebLeadsEditViewModel webLeadsEditViewModel)
        {
            int channelId = (int)ERPChannelsEnum.WebERP;
            DatabaseClient firebaseDbBusiness = new DatabaseClient();
            if (ModelState.IsValid)
            {
                var user = await _context.User.FirstOrDefaultAsync(m => m.Login == User.FindFirst("user").Value);
                var customer = GlobalFunctions.CloneCustomer(webLeadsEditViewModel);
                customer.leadCreationDate = DateTime.Now;
                customer.customerId = "C" + "000" + (int)(_context.Customers.Count() + 1);
                customer.lastModifiedBy = user.Id.ToString();
                _context.Customers.Add(customer);
                await _context.SaveChangesAsync();
                
                GlobalFunctions.SaveComments(_context, webLeadsEditViewModel.Comment, customer.customerId,
                    Convert.ToString(channelId), user.Id.ToString());

                GlobalFunctions.SaveHistory(_context, Convert.ToString(channelId), HistoryActions.NewLead,
                    customer.customerId, Convert.ToString(user.Id), "New Web Lead Added from Send To CRM option");

                await firebaseDbBusiness.RemoveLeadDataFromRealTimeDB(webLeadsEditViewModel.keyReference);

                return RedirectToAction(nameof(Index));
            }
            return View(webLeadsEditViewModel);
        }

        // GET: Business/Edit/5
        public async Task<IActionResult> Edit(string? keyReference)
        {
            if (keyReference == null)
            {
                return NotFound();
            }

            DatabaseClient firebaseDbBusiness = new DatabaseClient();

            var LeadData = await firebaseDbBusiness.GetLeadByReference(keyReference);

            if (LeadData == null)
            {
                return NotFound();
            }
            var customer = new WebLeadsEditViewModel();
            customer.name = LeadData.name;
            customer.leadCreationDate = DateTime.Now;
            customer.leadSourceCode = "WebLead";
            customer.projectCode = LeadData.projectName;
            customer.mobile = LeadData.mobile;
            customer.emailId = LeadData.email=="No Email." || LeadData.email == "emi calculator" ? "noemail@nirala-estate.org": LeadData.email;
            customer.followupDate = default(DateTime);
            customer.Comment = "";
            customer.keyReference= keyReference;
            var user = await _context.User.FirstOrDefaultAsync(m => m.Login == User.FindFirst("user").Value);
            ViewBag.userId = user.Id;
            List<Project> projectsList = _context.Project.ToList();
            ViewData["projects"] = projectsList;
            List<User> usersList = _context.User.ToList();
            ViewBag.users = usersList;
            List<LeadSource> leadSourceList = _context.LeadSource.ToList();
            ViewData["leadSources"] = leadSourceList;
            return View(customer);

        }

        // POST: Business/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details, see http://go.microsoft.com/fwlink/?LinkId=317598.

        // GET: Business/Delete/5
        public async Task<IActionResult> Delete(string? keyReference)
        {
            if (keyReference == null)
            {
                return NotFound();
            }

            DatabaseClient firebaseDbBusiness = new DatabaseClient();

            var LeadData = await firebaseDbBusiness.GetLeadByReference(keyReference);
            var WebLeadsData = new WebLeadsViewModel();
            WebLeadsData.date = LeadData.date;
            WebLeadsData.mobile = LeadData.mobile;
            WebLeadsData.email = LeadData.email;
            WebLeadsData.keyReference = LeadData.keyReference;
            WebLeadsData.projectName = LeadData.projectName;
            WebLeadsData.name = LeadData.name;
            WebLeadsData.deleteComment = "";
            return View(WebLeadsData);
        }

        //// POST: Business/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(string? keyReference, WebLeadsViewModel leadmodal)
        {
            DatabaseClient firebaseDbBusiness = new DatabaseClient();

            string sdeleteComment = Request.Form["deleteComment"];

            if (!string.IsNullOrWhiteSpace(keyReference))
            {
                var LeadData = await firebaseDbBusiness.GetLeadByReference(keyReference);
                var user = await _context.User.FirstOrDefaultAsync(m => m.Login == User.FindFirst("user").Value);

                var DeletedLeadsData = new DeletedWebLeads();
                DeletedLeadsData.date = LeadData.date;
                DeletedLeadsData.mobile = LeadData.mobile;
                DeletedLeadsData.email =string.IsNullOrWhiteSpace(LeadData.email) ? "noemail@nirala-estate.org" : LeadData.email;
                DeletedLeadsData.keyReference = LeadData.keyReference;
                DeletedLeadsData.projectName = LeadData.projectName;
                DeletedLeadsData.name = LeadData.name;
                DeletedLeadsData.deleteComment = sdeleteComment;
                DeletedLeadsData.deletedBy = user.Id.ToString();
                DeletedLeadsData.deletedDate = DateTime.Now.ToString();
                _context.DeletedWebLeads.Add(DeletedLeadsData);
                await _context.SaveChangesAsync();

                await firebaseDbBusiness.RemoveLeadDataFromRealTimeDB(keyReference);
            }
            return RedirectToAction(nameof(Index));
        }

       
        [HttpPost]
        public async Task<IActionResult> DeleteSelected(selectedLeads leadsObjFromView)
        {
            DatabaseClient firebaseDbBusiness = new DatabaseClient();
            string sdeleteComment = "";
            if (string.IsNullOrWhiteSpace(leadsObjFromView.deleteComment))
            {
                sdeleteComment = "Deleted using bulk delete option";
            }
            else
            {
                sdeleteComment = leadsObjFromView.deleteComment;
            }
            
            if (leadsObjFromView.leads.Count>0)
            {
                var AllLeads= await firebaseDbBusiness.GetStudents();
                
                foreach (var leadKey in leadsObjFromView.leads)
                {
                    var LeadData =  AllLeads.Find(m => m.keyReference == leadKey);
                    var user = await _context.User.FirstOrDefaultAsync(m => m.Login == User.FindFirst("user").Value);
                    var DeletedLeadsData = new DeletedWebLeads();
                    DeletedLeadsData.date = LeadData.date;
                    DeletedLeadsData.mobile = LeadData.mobile;
                    DeletedLeadsData.email = string.IsNullOrWhiteSpace(LeadData.email) ? "noemail@nirala-estate.org" : LeadData.email;
                    DeletedLeadsData.keyReference = LeadData.keyReference;
                    DeletedLeadsData.projectName = LeadData.projectName;
                    //DeletedLeadsData.name = LeadData.name;
                    DeletedLeadsData.name = LeadData.name == "" || string.IsNullOrWhiteSpace(LeadData.name) ? "No Name" : LeadData.name;
                    DeletedLeadsData.deleteComment = sdeleteComment;
                    DeletedLeadsData.deletedBy = user.Id.ToString();
                    DeletedLeadsData.deletedDate = DateTime.Now.ToString();
                    _context.DeletedWebLeads.Add(DeletedLeadsData);
                    await _context.SaveChangesAsync();

                    await firebaseDbBusiness.RemoveLeadDataFromRealTimeDB(leadKey);
                }
            }
            return RedirectToAction(nameof(Index));
        }

        [HttpPost]
        public async Task<IActionResult> SendToCRMSelectedLeads(selectedLeads leadsObjFromView)
        {
            DatabaseClient firebaseDbBusiness = new DatabaseClient();
            string sUserComment = "";
            if (string.IsNullOrWhiteSpace(leadsObjFromView.deleteComment))
            {
                sUserComment = "Sent To CRM using bulk send option";
            }
            else
            {
                sUserComment = leadsObjFromView.deleteComment;
            }

            if (leadsObjFromView.leads.Count > 0)
            {
                var AllLeads = await firebaseDbBusiness.GetStudents();
                int channelId = (int)ERPChannelsEnum.WebERP;
                foreach (var leadKey in leadsObjFromView.leads)
                {
                    var LeadData = AllLeads.Find(m => m.keyReference == leadKey);
                    var user = await _context.User.FirstOrDefaultAsync(m => m.Login == User.FindFirst("user").Value);
                    Customer customer = new Customer();
                    customer.Id =0;
                    if(string.IsNullOrWhiteSpace(LeadData.date))
                    {
                        customer.leadCreationDate = DateTime.ParseExact(DateTime.Now.ToString(), "MM/dd/yyyy HH:mm:ss", CultureInfo.InvariantCulture);
                    }
                    else
                    {
                        customer.leadCreationDate = DateTime.ParseExact(LeadData.date, "MM/dd/yyyy HH:mm:ss", CultureInfo.InvariantCulture);
                    }
                    
                    customer.lastUpdateToken = DateTime.Now.ToString("yyyy-MM-ddTHH:mm:ss");
                    //customer.name = LeadData.name;
                    customer.name= LeadData.name == "" || string.IsNullOrWhiteSpace(LeadData.name) ? "No Name" : LeadData.name;
                    customer.emailId = LeadData.email == "No Email." || LeadData.email == "emi calculator" ? "noemail@nirala-estate.org" : LeadData.email ;
                    customer.followupDate = default(DateTime);
                    customer.leadSourceCode = "WebLead";
                    customer.leadStatus =Convert.ToString((int)LeadStatusEnum.NewLead);
                    customer.mobile = LeadData.mobile;
                    customer.projectCode = LeadData.projectName;
                    customer.customerId = "C" + "000" + (int)(_context.Customers.Count() + 1);
                    customer.lastModifiedBy = user.Id.ToString();
                    _context.Customers.Add(customer);
                    await _context.SaveChangesAsync();

                    GlobalFunctions.SaveComments(_context, sUserComment, customer.customerId,
                        Convert.ToString(channelId), user.Id.ToString());

                    GlobalFunctions.SaveHistory(_context, Convert.ToString(channelId), HistoryActions.NewLead,
                            customer.customerId, Convert.ToString(user.Id), "New Web Lead Added from bulk Send To CRM option");

                   await firebaseDbBusiness.RemoveLeadDataFromRealTimeDB(leadKey);
                }
            }
            return RedirectToAction(nameof(Index));
        }

        private bool CustomerExists(int id)
        {
            return _context.Customers.Any(e => e.Id == id);
        }
    }
}
