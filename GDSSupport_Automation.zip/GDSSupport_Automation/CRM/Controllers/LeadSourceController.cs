using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using CRM.Data;
using CRM.Models;
using Microsoft.AspNetCore.Authorization;
using CRM.ViewModels;

namespace CRM.Controllers
{
    public class LeadSourceController : Controller
    {
        private readonly CRMContext _context;

        public LeadSourceController(CRMContext context)
        {
            _context = context;
        }

        // GET: Business
        [Authorize]
        public async Task<IActionResult> Index()
        {
            List<LeadSourceViewModel> listofleadsources= new List<LeadSourceViewModel>();
            List<LeadSource> leadsources = await _context.LeadSource.ToListAsync();
            List<Customer> customers = await _context.Customers.ToListAsync();
            foreach (LeadSource leadsrc in leadsources)
            {
                LeadSourceViewModel leadsrcviewmdl= new LeadSourceViewModel();
                leadsrcviewmdl.leadSourceCode = leadsrc.leadSourceCode;
                leadsrcviewmdl.leadSourceName  = leadsrc.leadSourceName;
                if(customers.Exists(cust => cust.leadSourceCode== leadsrc.leadSourceCode))
                {
                    leadsrcviewmdl.IsUsedInTransaction= true;
                }
                else
                {
                    leadsrcviewmdl.IsUsedInTransaction = false;
                }
                listofleadsources.Add(leadsrcviewmdl);
            }
            return View(listofleadsources);
        }

        // GET: Business/Details/5
        [Authorize]
        public async Task<IActionResult> Details(string? leadSourceCode)
        {
            if (leadSourceCode == null)
            {
                return NotFound();
            }
            ViewBag.Message = "Lead Sources";
            var business = await _context.LeadSource
                .FirstOrDefaultAsync(m => m.leadSourceCode == leadSourceCode);
            return View(business);
        }

        //// GET: Business/Create
        public IActionResult Create()
        {
            return View();
        }

        //// POST: Business/Create
        //// To protect from overposting attacks, enable the specific properties you want to bind to, for 
        //// more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("leadSourceCode,leadSourceName")] LeadSource leadSource)
        {
            if (ModelState.IsValid)
            {
                _context.Add(leadSource);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(leadSource);
        }

        // GET: Business/Edit/5
        public async Task<IActionResult> Edit(string? leadSourceCode)
        {
            if (leadSourceCode == null)
            {
                return NotFound();
            }

            var business = await _context.LeadSource
                .FirstOrDefaultAsync(m => m.leadSourceCode == leadSourceCode);
            if (business == null)
            {
                return NotFound();
            }
            return View(business);

        }

        // POST: Business/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(string? leadSourceCode, [Bind("leadSourceCode,leadSourceName")] LeadSource leadSource)
        {
            if (leadSourceCode != leadSource.leadSourceCode)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(leadSource);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!LeadSourceExists(leadSource.leadSourceCode))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(leadSource);
        }

        // GET: Business/Delete/5
        public async Task<IActionResult> Delete(string? leadSourceCode)
        {
            if (leadSourceCode == null)
            {
                return NotFound();
            }

            var business = await _context.LeadSource
                .FirstOrDefaultAsync(m => m.leadSourceCode == leadSourceCode);
            if (business == null)
            {
                return NotFound();
            }
            return View(business);
        }

        //// POST: Business/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(string? leadSourceCode)
        {
            var leadSource = await _context.LeadSource.FindAsync(leadSourceCode);
            _context.LeadSource.Remove(leadSource);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool LeadSourceExists(string leadSourceCode)
        {
            return _context.LeadSource.Any(e => e.leadSourceCode == leadSourceCode);
        }
    }
}
