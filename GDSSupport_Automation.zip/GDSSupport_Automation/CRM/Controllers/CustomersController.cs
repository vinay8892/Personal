using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using CRM.Data;
using CRM.Models;
using Microsoft.AspNetCore.Authorization;
using CRM.ViewModels;
using Newtonsoft.Json;
using CRM.Utilities;
using System.Threading.Channels;

namespace CRM.Controllers
{
    public class CustomersController : Controller
    {
        private readonly CRMContext _context;

        public CustomersController(CRMContext context)
        {
            _context = context;
        }

        // GET: Contacts
        [Authorize]
        public async Task<IActionResult> Index(string filter)
        {
            var user = await _context.User.FirstOrDefaultAsync(m => m.Login == User.FindFirst("user").Value);
            ViewBag.userId = user.Id;
            List<Project> projectsList = _context.Project.ToList();
            ViewData["projects"] = projectsList;
            List<User> usersList = _context.User.ToList();
            ViewBag.users = usersList;
            List<LeadSource> leadSourceList = _context.LeadSource.ToList();
            ViewData["leadSources"] = leadSourceList;
            var qry = _context.Customers.AsNoTracking().OrderByDescending(p => p.Id).AsQueryable();
            var role = await _context.Role.FindAsync(Convert.ToInt32(user.RoleId));
            if (role.Name== "User")
            {
                qry = qry.Where(p => p.assignedTo.ToUpper().Equals(user.Id.ToString()));
            }
            if (!string.IsNullOrWhiteSpace(filter))
            {
                //qry = qry.Where(p => p.name.Contains(filter));
                qry = qry.Where(p => p.name.ToUpper().Contains(filter.ToUpper()));
            }
            var model = await qry.ToListAsync();
            ViewBag.filter = filter;
            return View(model);
        }

        // GET: Contacts/Details/5
        [Authorize]
        public async Task<IActionResult> Details(int? Id)
        {
            if (Id == null)
            {
                return NotFound();
            }
            var customers = await _context.Customers
                        .FirstOrDefaultAsync(m => m.Id == Id);
            if (customers == null)
            {
                return NotFound();
            }
            var user = await _context.User.FirstOrDefaultAsync(m => m.Login == User.FindFirst("user").Value);
            ViewBag.userId = user.Id;
            var role = _context.Role.Find(Convert.ToInt32(user.RoleId));
            List<Project> projectsList = _context.Project.ToList();
            ViewData["projects"] = projectsList;
            List<User> usersList = _context.User.ToList();
            ViewBag.users = usersList;
            List<LeadSource> leadSourceList = _context.LeadSource.ToList();
            ViewData["leadSources"] = leadSourceList;
            List<CustomerActionHistory> customerHistory = null;
            if (role.Name=="Admin" || customers.shareHistory=="1")
            {
                customerHistory = _context.CustomerActionHistory.Where(x => x.customerId == customers.customerId).ToList();
            }
            else
            {
                customerHistory = _context.CustomerActionHistory.Where(x => x.customerId == customers.customerId && x.userId== user.Id.ToString()).ToList();
            }
            
            List<User> users = _context.User.ToList();
            foreach (CustomerActionHistory custHist in customerHistory)
            {
                var commentUser = users.FirstOrDefault(userobj => userobj.Id.ToString() == custHist.userId);
                if (commentUser != null)
                {
                    custHist.userId = commentUser.Name + " " + commentUser.Surname;
                }
                custHist.CRMChannel=GlobalFunctions.GetERPChannelName(custHist.CRMChannel);
            }
            ViewData["customerHistory"] = customerHistory;

            List<CustomerComment> commentsList = null;
            if (role.Name == "Admin" || customers.shareComments == "1")
            {
                commentsList = _context.CustomerComments.Where(x => x.customerId == customers.customerId).ToList();
            }
            else
            {
                 commentsList = _context.CustomerComments.Where(x => x.customerId == customers.customerId && x.commentedBy== user.Id.ToString()).ToList();
            }
                
            foreach (CustomerComment custcomm in commentsList)
            {
                var commentUser = users.FirstOrDefault(userobj => userobj.Id.ToString() == custcomm.commentedBy);
                if (commentUser != null)
                {
                    custcomm.commentedBy = commentUser.Name + " " + commentUser.Surname;
                }
            }
            ViewData["comments"] = commentsList;

            return View(customers);
        }

        // GET: Contacts/Create
        [Authorize]
        public async Task<IActionResult> CreateAsync(int? com)
        {
            ViewBag.id = com;
            var user = await _context.User.FirstOrDefaultAsync(m => m.Login == User.FindFirst("user").Value);
            ViewBag.user = user.Id;
            List<Project> projectsList = _context.Project.ToList();
            ViewData["projects"] = projectsList;
            List<User> usersList = _context.User.ToList();
            ViewBag.users = usersList;
            List<LeadSource> leadSourceList = _context.LeadSource.ToList();
            ViewData["leadSources"] = leadSourceList;
            WebLeadsEditViewModel webLeadsEditViewModel= new WebLeadsEditViewModel();
            webLeadsEditViewModel.followupDate= default(DateTime);
            webLeadsEditViewModel.emailId = "noemail@nirala-estate.org";
            return View(webLeadsEditViewModel);
        }

        // POST: Contacts/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create( WebLeadsEditViewModel webLeadsCreateViewModel)
        {
            if (ModelState.IsValid)
            {
                int channelId = (int)ERPChannelsEnum.WebERP;
                var user = await _context.User.FirstOrDefaultAsync(m => m.Login == User.FindFirst("user").Value);
                var customer = GlobalFunctions.CloneCustomer(webLeadsCreateViewModel);
                customer.leadCreationDate = DateTime.Now;
                customer.customerId = "C" + "000" + (int)(_context.Customers.Count() + 1);
                customer.lastModifiedBy = user.Id.ToString();
                _context.Add(customer);
                await _context.SaveChangesAsync();

                GlobalFunctions.SaveComments(_context, webLeadsCreateViewModel.Comment, customer.customerId,
                                Convert.ToString(channelId), user.Id.ToString());

                GlobalFunctions.SaveHistory(_context, Convert.ToString(channelId), HistoryActions.NewLead,
                                customer.customerId, Convert.ToString(user.Id), "New Lead has been created");

                return RedirectToAction(nameof(Index));
            }
            return View(webLeadsCreateViewModel);
        }

        // GET: Contacts/Edit/5
        [Authorize]
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }
            var customers = await _context.Customers.FindAsync(id);
            if (customers == null)
            {
                return NotFound();
            }
            var user = await _context.User.FirstOrDefaultAsync(m => m.Login == User.FindFirst("user").Value);
            ViewBag.userId = user.Id;
            List<Project> projectsList = _context.Project.ToList();
            ViewData["projects"] = projectsList;
            List<User> usersList = _context.User.ToList();
            ViewBag.users = usersList;
            List<LeadSource> leadSourceList = _context.LeadSource.ToList();
            ViewData["leadSources"] = leadSourceList;
            List<CustomerComment> commentsList;
            var role = await _context.Role.FindAsync(Convert.ToInt32(user.RoleId));
            if (role.Name=="User")
            {
                if(customers.shareComments=="1")
                {
                    commentsList = _context.CustomerComments.Where(x => x.customerId == customers.customerId).ToList();
                }
                else
                {
                    commentsList = _context.CustomerComments.Where(x => x.customerId == customers.customerId && x.commentedBy == user.Id.ToString()).ToList();
                }
                
            }
            else
            {
                commentsList = _context.CustomerComments.Where(x => x.customerId == customers.customerId).ToList();
            }
            
            List<User> users= _context.User.ToList();
            foreach(CustomerComment custcomm in commentsList)
            {
                var commentUser = users.FirstOrDefault(userobj => userobj.Id.ToString() == custcomm.commentedBy);
                if (commentUser != null)
                {
                    custcomm.commentedBy = commentUser.Name + " " + commentUser.Surname;
                }
            }
            ViewData["comments"] = commentsList;
            var serialized = JsonConvert.SerializeObject(customers);
            var customerViewModal = JsonConvert.DeserializeObject<WebLeadsEditViewModel>(serialized);
            //customerViewModal.followupDate = DateTime.Now;
            return View(customerViewModal);
        }

        // POST: Contacts/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, WebLeadsEditViewModel webLeadsEditViewModel)
        {
            if (id != webLeadsEditViewModel.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    int channelId = (int)ERPChannelsEnum.WebERP;
                    var user = await _context.User.FirstOrDefaultAsync(m => m.Login == User.FindFirst("user").Value);
                    var customerOriginal = await _context.Customers.FirstOrDefaultAsync(m => m.Id == id);

                    var customer = GlobalFunctions.CloneCustomer(webLeadsEditViewModel);                    
                    customer.lastModifiedBy= user.Id.ToString();
                    customer.assignedTo = customerOriginal.assignedTo;
                    string historyDescriptionOnEdit = GlobalFunctions.HistoryDescriptionOnEdit(customerOriginal, customer, _context.User);
                    if (historyDescriptionOnEdit == "No Updation on lead" && !string.IsNullOrWhiteSpace(webLeadsEditViewModel.Comment))
                    {
                        historyDescriptionOnEdit = "New Comment : " + webLeadsEditViewModel.Comment;
                    }
                    if (customerOriginal != null)
                    {
                        // detach
                        _context.Entry(customerOriginal).State = EntityState.Detached;
                    }

                    _context.Customers.Update(customer);
                    await _context.SaveChangesAsync();

                    GlobalFunctions.SaveComments(_context, webLeadsEditViewModel.Comment, webLeadsEditViewModel.customerId,
                    Convert.ToString(channelId), user.Id.ToString());
                    
                    GlobalFunctions.SaveHistory(_context, Convert.ToString(channelId), HistoryActions.UpdateLead,
                        customer.customerId, Convert.ToString(user.Id), historyDescriptionOnEdit);

                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!CustomerExists(webLeadsEditViewModel.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(webLeadsEditViewModel);
        }

        // GET: Contacts/Delete/5
        [Authorize]
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var customers = await _context.Customers.FindAsync(id);
            if (customers == null)
            {
                return NotFound();
            }
            var user = await _context.User.FirstOrDefaultAsync(m => m.Login == User.FindFirst("user").Value);
            ViewBag.userId = user.Id;
            List<Project> projectsList = _context.Project.ToList();
            ViewData["projects"] = projectsList;
            List<User> usersList = _context.User.ToList();
            ViewBag.users = usersList;
            List<LeadSource> leadSourceList = _context.LeadSource.ToList();
            ViewData["leadSources"] = leadSourceList;
            return View(customers);
        }

        // POST: Contacts/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var customer = await _context.Customers.FindAsync(id);
            //contact.IsDeleted = 1;
            _context.Customers.Remove(customer);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool CustomerExists(int id)
        {
            return _context.Customers.Any(e => e.Id == id);
        }

        public ActionResult ModalPopUp()
        {
            return View();
        }

    }
}
