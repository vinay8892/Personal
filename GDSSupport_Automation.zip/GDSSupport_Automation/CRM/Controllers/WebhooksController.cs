﻿using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System.Net.Http;
using System.Net;
using System.Threading.Tasks;
using System;
using System.Linq;
using CRM.ApiModels;
using CRM.Services;
using System.Collections.Generic;
using System.Data.Entity.Core.Metadata.Edm;

namespace CRM.Controllers
{
    [Route("api/[controller]")]
    public class WebhooksController : Controller
    {
        #region Fields

        private const string _verificationToken = "shuklanaitikbhuvika";
        private readonly INotificationService _notificationService;
        #endregion

        #region Get Request

        [HttpGet]
        public string Get()
        {
            try
            {
                var mode = Request.Query["hub.mode"].ToString();
                var challenge = Request.Query["hub.challenge"].ToString();
                var verifyToken = Request.Query["hub.verify_token"].ToString();

                if (verifyToken == _verificationToken)
                    return challenge;
                else
                    return HttpStatusCode.BadRequest.ToString();
            }
            catch (Exception ex)
            {
                return ex.Message.ToString();
            }
        }

        #endregion Get Request

        #region Post Request

        //[HttpPost]
        //public async Task<HttpResponseMessage> Post([FromBody] JsonDataModel data)
        //{
        //    try
        //    {
        //        var entry = data.Entry.FirstOrDefault();
        //        var change = entry?.Changes.FirstOrDefault();
        //        if (change == null) return new HttpResponseMessage(HttpStatusCode.BadRequest);

        //        //Generate user access token here https://developers.facebook.com/tools/accesstoken/
        //        const string token = "shuklanaitikbhuvika";

        //        var leadUrl = $"https://graph.facebook.com/v14.0/{change.Value.LeadGenId}?access_token={token}";
        //        var formUrl = $"https://graph.facebook.com/v14.0/{change.Value.FormId}?access_token={token}";


        //        if (!string.IsNullOrEmpty(token))
        //        {
        //            using (var httpClientLead = new HttpClient())
        //            {
        //                var response = await httpClientLead.GetStringAsync(formUrl);
        //                if (!string.IsNullOrEmpty(response))
        //                {
        //                    var jsonObjLead = JsonConvert.DeserializeObject<LeadFormData>(response);
        //                    //jsonObjLead.Name contains the lead ad name

        //                    //If response is valid get the field data
        //                    using (var httpClientFields = new HttpClient())
        //                    {
        //                        var responseFields = await httpClientFields.GetStringAsync(leadUrl);
        //                        if (!string.IsNullOrEmpty(responseFields))
        //                        {
        //                            var jsonObjFields = JsonConvert.DeserializeObject<LeadData>(responseFields);
        //                            //jsonObjFields.FieldData contains the field value
        //                        }
        //                    }
        //                }
        //            }
        //        }
        //        return new HttpResponseMessage(HttpStatusCode.OK);
        //    }
        //    catch (Exception ex)
        //    {
        //        return new HttpResponseMessage(HttpStatusCode.BadGateway);
        //    }
        //}
        [HttpPost]
        public async Task<HttpResponseMessage> Post([FromBody] LeadGenModel data)
        {
            try
            {
                var field = data.Field;
                var valueObj = data?.Value;
                if (valueObj == null) return new HttpResponseMessage(HttpStatusCode.BadRequest);

                //Generate user access token here https://developers.facebook.com/tools/accesstoken/
                const string token = "7875079489208241|QjQ9Mq3nmkFDklvfmNKoMY8nabk";

                var leadUrl = $"https://graph.facebook.com/v20.0/{valueObj.leadgen_id}?access_token={token}";
                //var formUrl = $"https://graph.facebook.com/v20.0/{valueObj.form_id}?access_token={token}";


                if (!string.IsNullOrEmpty(token))
                {
                    //using (var httpClientLead = new HttpClient())
                    //{
                    //    var response = await httpClientLead.GetStringAsync(formUrl);
                    //    if (!string.IsNullOrEmpty(response))
                    //    {
                    //        var jsonObjLead = JsonConvert.DeserializeObject<LeadFormData>(response);
                            //jsonObjLead.Name contains the lead ad name

                            //If response is valid get the field data
                            using (var httpClientFields = new HttpClient())
                            {
                                var responseFields = await httpClientFields.GetStringAsync(leadUrl);
                                if (!string.IsNullOrEmpty(responseFields))
                                {
                                    var jsonObjFields = JsonConvert.DeserializeObject<LeadData>(responseFields);
                                    //jsonObjFields.FieldData contains the field value
                                    List<FieldData> lstfielddata = jsonObjFields.field_data;
                                    LeadRequest ldreq = new LeadRequest();
                                    foreach (FieldData fldData in lstfielddata)
                                    {
                                        if(fldData.name=="name")
                                        {
                                            ldreq.name= fldData.values[0];
                                        }
                                         else if(fldData.name == "Phone")
                                        {
                                            ldreq.mobile = fldData.values[0];
                                        }

                                    }
                                    ldreq.email = "";
                                    ldreq.projectName = "NiralaEstate";
                                    ldreq.date = "";
                                    var leadcntrlr = new NewLeadsController(_notificationService);
                                    await leadcntrlr.SaveLead(ldreq);

                                }
                            }
                    //    }
                    //}
                }
                return new HttpResponseMessage(HttpStatusCode.OK);
            }
            catch (Exception ex)
            {
                return new HttpResponseMessage(HttpStatusCode.BadGateway);
            }
        }
        #endregion Post Request
    }
}
