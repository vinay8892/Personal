using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using CRM.Data;
using CRM.Models;
using Microsoft.AspNetCore.Authorization;
using System.Text;

namespace CRM.Controllers
{
    public class ReportsController : Controller
    {
        private readonly CRMContext _context;

        public ReportsController(CRMContext context)
        {
            _context = context;
        }

        // GET: Business
        [Authorize]
        public async Task<IActionResult> Index()
        {
            return View();
        }

        public async Task<IActionResult> DeletedRecords()
        {
            return View(await _context.DeletedWebLeads.ToListAsync());
        }

        public async Task<IActionResult> NewLeads()
        {
            int leadstatus =(int) LeadStatusEnum.NewLead;
            List<Customer> customerList = await _context.Customers.Where(cust => cust.leadStatus == leadstatus.ToString()).ToListAsync();
            List<Project> projects=await _context.Project.ToListAsync();
            foreach(Customer cust in customerList)
            {
                cust.leadStatus = "New Lead";
                Project prjct=projects.FirstOrDefault(prj =>prj.projectCode== cust.projectCode);
                if(prjct!=null)
                {
                    cust.projectCode = prjct.projectName;
                }
            }
            return View(customerList);
        }

        public async Task<IActionResult> InterestedLeads()
        {
            int leadstatus = (int)LeadStatusEnum.Interested;
            List<Customer> customerList = await _context.Customers.Where(cust => cust.leadStatus == leadstatus.ToString()).ToListAsync();
            List<Project> projects = await _context.Project.ToListAsync();
            foreach (Customer cust in customerList)
            {
                cust.leadStatus = "Interested Lead";
                Project prjct = projects.FirstOrDefault(prj => prj.projectCode == cust.projectCode);
                if (prjct != null)
                {
                    cust.projectCode = prjct.projectName;
                }
            }
            return View(customerList);
        }

        public async Task<IActionResult> FollowUpLeads()
        {
            int leadstatus = (int)LeadStatusEnum.FollowUp;
            List<Customer> customerList = await _context.Customers.Where(cust => cust.leadStatus == leadstatus.ToString()).ToListAsync();
            List<Project> projects = await _context.Project.ToListAsync();
            foreach (Customer cust in customerList)
            {
                cust.leadStatus = "FollowUp Lead";
                Project prjct = projects.FirstOrDefault(prj => prj.projectCode == cust.projectCode);
                if (prjct != null)
                {
                    cust.projectCode = prjct.projectName;
                }
            }
            return View(customerList);
        }

        [HttpPost]
        public FileResult ExporttoExcel(string HtmlTable)
        {
            return File(Encoding.ASCII.GetBytes(HtmlTable), "application/vnd.ms-excel", "htmltable.xls");
        }


    }
}
