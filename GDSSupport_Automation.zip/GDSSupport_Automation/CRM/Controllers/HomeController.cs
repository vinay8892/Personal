﻿using System.Diagnostics;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using CRM.Models;
using CRM.Data;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Authorization;
using System.Collections.Generic;
using System.Linq;
using System;
using System.Globalization;
using NetCoreAudio;
using Newtonsoft.Json;
using System.Net.Http;
using System.Text;
using System.Configuration;
using Microsoft.VisualStudio.Web.CodeGeneration.Contracts.Messaging;
using System.Xml.Linq;
using Microsoft.Extensions.Configuration;
using System.Data.Entity;
using CRM.Utilities;

namespace CRM.Controllers
{
    public class HomeController : Controller
    {
        //private readonly ILogger<HomeController> _logger;

        const string SessionName = "_Name";
        const string SessionAge = "_Age";
        private const string sFormat = "yyyy-MM-dd";

        private readonly CRMContext _context;
        private IConfiguration configuration;

        public HomeController(CRMContext context, IConfiguration iConfig)
        {
            _context = context;
            configuration = iConfig;
        }

        [Authorize]
        public async Task<IActionResult> Index()
        {

            var user = await _context.User.FindAsync(1);
            HttpContext.Session.SetString(SessionName, "Adam!");
            string fileName = @"D:\\ringtone_30_secs.mp3";
            if (user == null)
            {
                return NotFound();
            }
            ViewBag.Name = HttpContext.Session.GetString(SessionName);
            List<Customer> customerFollowupList = _context.Customers.ToList();
            customerFollowupList=customerFollowupList.Where(cust => cust.followupDate.ToString(sFormat) == DateTime.Now.ToString(sFormat)).ToList();
            ViewBag.customers = customerFollowupList;
            //string dbConn2 = configuration.GetValue<string>("MySettings:DbConnection");
            string sEmailSendUrl = configuration.GetValue<string>("EmailSendApiUrl");
            ViewBag.sEmailSendUrl = sEmailSendUrl;
            //var player = new Player();
            //player.PlaybackFinished += OnPlaybackFinished;
            //player.Play(fileName).Wait();
            string sFollowupEmailIds = GlobalFunctions.CRMSettingValue(_context, "followupEmailIds");
            ViewBag.sFollowupEmailIds = sFollowupEmailIds;
            return View(user);
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
        private static void OnPlaybackFinished(object sender, EventArgs e)
        {
            Console.WriteLine("Playback finished");
        }
    }
}


