﻿using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;
using CRM.Services;
using CRM.ApiModels;
using CRM.BusinessLayer;
using System.Collections.Generic;


namespace CRM.Controllers
{

    [Route("api/[controller]")]
  
    public class NewLeadsController : ControllerBase
    {
        private readonly INotificationService _notificationService;

        public NewLeadsController(INotificationService notificationService)
        {
            _notificationService = notificationService;
        }

        [HttpPost]
        public async Task<IActionResult> SaveLead([FromForm] LeadRequest LeadRequest)
        {
            
            DatabaseClient firebaseDbBusiness = new DatabaseClient();
            await firebaseDbBusiness.SaveNewLeadsToRealTimeDB(LeadRequest);
            List<FCMTokenData> tokensList = new List<FCMTokenData>();
            tokensList = await firebaseDbBusiness.GetSubscribedDevices();

            foreach (var tokendata in tokensList)
            {
                NotificationModel notificationModel = new NotificationModel();
                notificationModel.Title = "New Lead Received";
                notificationModel.Body = "Name : " + LeadRequest.name + ", Mobile :" + LeadRequest.mobile;
                notificationModel.DeviceId = tokendata.deviceToken;
                notificationModel.IsAndroiodDevice = true;
                await _notificationService.SendNotification(notificationModel);
            }

            return new OkResult();
        }


    }
}
