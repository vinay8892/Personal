using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;
using System.Linq;
using System.Security.Claims;
using System.Security.Cryptography;
using System.Security.Cryptography.Xml;
using System.Text;
using System.Threading.Tasks;
using CRM.BusinessLayer;
using CRM.Data;
using CRM.Models;
using CRM.Utilities;
using CRM.ViewModels;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using CRM.ApiModels;

namespace CRM.Controllers
{
    [Route("api/[controller]")]
    public class MobileApiController : Controller
    {
        private readonly CRMContext _context;

        public MobileApiController(CRMContext context)
        {
            _context = context;
        }

        private bool ValidateLoginAsync(string userName, string password)
        {
            // For this sample, all logins are successful.
            var user = _context.User.FirstOrDefault(m => m.Login == userName);
            try
            {
                if(user!=null)
                {
                    if (password == user.Password && user.IsDeleted == 0)
                    {
                        return true;
                    }
                    else
                    {
                        return false;
                    }
                }
                else
                {
                    return false;
                }

            }
            catch (Exception)
            {
                return false;
            }
        }


        public string HashPassword(string password)
        {
            byte[] hashedPassword;
            using (MD5 md5 = MD5.Create())
            {
                hashedPassword = md5.ComputeHash(Encoding.UTF8.GetBytes(password));
            }
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < hashedPassword.Length; i++)
            {
                sb.Append(hashedPassword[i].ToString("x2"));
            }

            return Convert.ToString(sb);
        }

        private string ReturnRole(string userName)
        {
            var user = _context.User.FirstOrDefault(m => m.Login == userName);
            var role = _context.Role.Find(Convert.ToInt32(user.RoleId));
            return role.Name;
        }

        [HttpGet("MastersList")]
        public async Task<MobileApiMasters> MastersList()
        {
            MobileApiMasters mobileApiMasterList = new MobileApiMasters();
            List<Project> projectsList = _context.Project.ToList();
            List<User> usersList = _context.User.ToList();
            List<LeadSource> leadSourceList = _context.LeadSource.ToList();
            mobileApiMasterList.leadSources = leadSourceList;
            mobileApiMasterList.users = usersList;
            mobileApiMasterList.projects = projectsList;

            return mobileApiMasterList;
        }

        [HttpPost("Login")]
        public async Task<LoginResponse> Login([FromBody] LoginModel model)
        {
            LoginResponse loginResponse = new LoginResponse();
            loginResponse.success = 0;
            loginResponse.role = "";
            model.Password = HashPassword(model.Password);

            if ( ValidateLoginAsync(model.UserName, model.Password))
            {
                string role =  ReturnRole(model.UserName);
                loginResponse.success = 1;
                loginResponse.role = role;
            }
            else
            {
                loginResponse.success = 0;
            }
            return loginResponse;

        }

        [HttpGet("GetFollowUps")]
        public async Task<List<Customer>> GetFollowUps()
        {
             string sFormat = "yyyy-MM-dd";
            List<Customer> customerFollowupList = _context.Customers.ToList();
            customerFollowupList = customerFollowupList.Where(cust => cust.followupDate.ToString(sFormat) == DateTime.Now.ToString(sFormat)).ToList();
            return customerFollowupList;
        }


        [HttpPost("SendToCRM")]
        public async Task<SendToCRMResponse> SendToCRM([FromBody] SendToCRMRequest model)
        {
            SendToCRMResponse SendtoCRMResponse = new SendToCRMResponse();
            SendtoCRMResponse.success = 0;
            SendtoCRMResponse.message = "";
            

            if (await saveSendToCRMRecordsAsync(model))
            {
                SendtoCRMResponse.success = 1;
                SendtoCRMResponse.message = "Data saved successfully";
            }
            else
            {
                SendtoCRMResponse.success = 0;
                SendtoCRMResponse.message = "Error occured while saving records";
            }
            return SendtoCRMResponse;

        }

        private async Task<Boolean> saveSendToCRMRecordsAsync(SendToCRMRequest model)
        {
            bool bSuccess = true;
            int channelId = (int)ERPChannelsEnum.MobileERP;
            DatabaseClient firebaseDbBusiness = new DatabaseClient();
            if (ModelState.IsValid)
            {
                var user = await _context.User.FirstOrDefaultAsync(m => m.Login == model.user);
                var customer = new Customer();
                customer.emailId = model.email == "No Email." || model.email == "emi calculator" ? "noemail@nirala-estate.org" : model.email;
                customer.name = model.name;
                customer.mobile=model.mobile;
                customer.projectCode = model.project;
                customer.Id = 0;
                customer.lastUpdateToken = DateTime.Now.ToString("yyyy-MM-ddTHH:mm:ss");
                customer.followupDate = default(DateTime);
                customer.leadSourceCode = "WebLead";
                customer.leadCreationDate = DateTime.Now;
                customer.customerId = "C" + "000" + (int)(_context.Customers.Count() + 1);
                customer.lastModifiedBy = user.Id.ToString();
                customer.leadStatus = Convert.ToString((int)LeadStatusEnum.NewLead);
                _context.Customers.Add(customer);
                await _context.SaveChangesAsync();

                GlobalFunctions.SaveComments(_context, model.comment, customer.customerId,
                    Convert.ToString(channelId), user.Id.ToString());

                GlobalFunctions.SaveHistory(_context, Convert.ToString(channelId), HistoryActions.NewLead,
                    customer.customerId, user.Id.ToString(), "New Web Lead Added from Send To CRM option");

                 await firebaseDbBusiness.RemoveLeadDataFromRealTimeDB(model.keyReference);
            }
            return bSuccess;
        }

        [HttpPost("RemoveLead")]
        public async Task<SendToCRMResponse> RemoveLead([FromBody] RemoveLeadRequest removeRequest)
        {
            SendToCRMResponse SendtoCRMResponse = new SendToCRMResponse();
            DatabaseClient firebaseDbBusiness = new DatabaseClient();
            string sdeleteComment = "";
            if (string.IsNullOrWhiteSpace(removeRequest.comment))
            {
                sdeleteComment = "Deleted Lead From Mobile App";
            }
            else
            {
                sdeleteComment = removeRequest.comment;
            }

            var AllLeads = await firebaseDbBusiness.GetStudents();

     
            var LeadData = AllLeads.Find(m => m.keyReference == removeRequest.keyReference);
            var user = await _context.User.FirstOrDefaultAsync(m => m.Login == removeRequest.user);
            var DeletedLeadsData = new DeletedWebLeads();
            DeletedLeadsData.date = LeadData.date;
            DeletedLeadsData.mobile = LeadData.mobile;
            DeletedLeadsData.email = string.IsNullOrWhiteSpace(LeadData.email) ? "noemail@nirala-estate.org" : LeadData.email;
            DeletedLeadsData.keyReference = LeadData.keyReference;
            DeletedLeadsData.projectName = LeadData.projectName;
            DeletedLeadsData.name = LeadData.name;
            DeletedLeadsData.deleteComment = sdeleteComment;
            DeletedLeadsData.deletedBy = user.Id.ToString();
            DeletedLeadsData.deletedDate = DateTime.Now.ToString();
            _context.DeletedWebLeads.Add(DeletedLeadsData);
            await _context.SaveChangesAsync();

            await firebaseDbBusiness.RemoveLeadDataFromRealTimeDB(removeRequest.keyReference);

            SendtoCRMResponse.success = 1;
            SendtoCRMResponse.message = "Data Deleted successfully";

            return SendtoCRMResponse;
        }

        [HttpGet("getStudentsWithoutTesnion")]
        public async Task<List<FireBaseLead>> GetData()
        {
            DatabaseClient firebaseDbBusiness = new DatabaseClient();

            var LeadData = await firebaseDbBusiness.GetStudents();

            return LeadData.ToList();
        }

        [HttpGet("GetUser")]
        public async Task<User> GetUser(string userName)
        {
            
            var userDetail = await _context.User.FirstOrDefaultAsync(m => m.Login == userName);
           
            return userDetail;
        }

    }
}
