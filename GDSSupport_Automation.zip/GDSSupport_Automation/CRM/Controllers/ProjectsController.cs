using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using CRM.Data;
using CRM.Models;
using Microsoft.AspNetCore.Authorization;
using CRM.ViewModels;

namespace CRM.Controllers
{
    public class ProjectsController : Controller
    {
        private readonly CRMContext _context;

        public ProjectsController(CRMContext context)
        {
            _context = context;
        }

        // GET: Business
        [Authorize]
        public async Task<IActionResult> Index()
        {
            List<ProjectViewModel> listofProjects = new List<ProjectViewModel>();
            List<Project> Projects = await _context.Project.ToListAsync();
            List<Customer> customers = await _context.Customers.ToListAsync();
            foreach (Project project in Projects)
            {
                ProjectViewModel projectviewmdl = new ProjectViewModel();
                projectviewmdl.projectCode = project.projectCode;
                projectviewmdl.projectName = project.projectName;
                projectviewmdl.projectLocation = project.projectLocation;
                if (customers.Exists(cust => cust.projectCode == project.projectCode))
                {
                    projectviewmdl.IsUsedInTransaction = true;
                }
                else
                {
                    projectviewmdl.IsUsedInTransaction = false;
                }
                listofProjects.Add(projectviewmdl);
            }
            return View(listofProjects);
        }

        // GET: Business/Details/5
        [Authorize]
        public async Task<IActionResult> Details(string? projectCode)
        {
            if (projectCode == null)
            {
                return NotFound();
            }
            ViewBag.Message = "Projects";
            var project = await _context.Project
                .FirstOrDefaultAsync(m => m.projectCode == projectCode);
            return View(project);
        }

        //// GET: Business/Create
        public IActionResult Create()
        {
            return View();
        }

        //// POST: Business/Create
        //// To protect from overposting attacks, enable the specific properties you want to bind to, for 
        //// more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("projectCode,projectName,projectLocation")] Project project)
        {
            if (ModelState.IsValid)
            {
                _context.Add(project);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(project);
        }

        // GET: Business/Edit/5
        public async Task<IActionResult> Edit(string? projectCode)
        {
            if (projectCode == null)
            {
                return NotFound();
            }

            var project = await _context.Project
                .FirstOrDefaultAsync(m => m.projectCode == projectCode);
            if (project == null)
            {
                return NotFound();
            }
            return View(project);

        }

        // POST: Business/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(string? projectCode, [Bind("projectCode,projectName,projectLocation")] Project project)
        {
            if (projectCode != project.projectCode)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(project);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!ProjectExists(project.projectCode))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(project);
        }

        // GET: Business/Delete/5
        public async Task<IActionResult> Delete(string? projectCode)
        {
            if (projectCode == null)
            {
                return NotFound();
            }

            var project = await _context.Project
                .FirstOrDefaultAsync(m => m.projectCode == projectCode);
            if (project == null)
            {
                return NotFound();
            }
            return View(project);
        }

        //// POST: Business/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(string? projectCode)
        {
            var project = await _context.Project.FindAsync(projectCode);
            _context.Project.Remove(project);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool ProjectExists(string projectCode)
        {
            return _context.Project.Any(e => e.projectCode == projectCode);
        }
    }
}
