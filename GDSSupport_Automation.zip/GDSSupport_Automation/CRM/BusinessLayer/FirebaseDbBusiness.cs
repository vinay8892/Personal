﻿using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;
using Firebase.Database;
using Firebase.Database.Query;
using System.Linq;
using System;
using CRM.Models;
using CRM.ApiModels;
using System.Collections.Generic;

namespace CRM.BusinessLayer
{
    public class DatabaseClient 
    {
      
        public async Task<ActionResult> RemoveLeadDataFromRealTimeDB(string sKeyReference)
        {
            var firebaseClient = new FirebaseClient("https://niralaestate-538ca-default-rtdb.firebaseio.com/");
            
            await firebaseClient
              .Child("Leads")
              .Child(sKeyReference)
              .DeleteAsync();
            //https://bolorundurowb.dev/posts/31/using-the-firebase-realtime-database-with-net

            return new OkResult();
        }

        public async Task<List<FireBaseLead>> GetStudents()
        {
            var firebaseClient = new FirebaseClient("https://niralaestate-538ca-default-rtdb.firebaseio.com/");
            var Leads = new List<FireBaseLead>();
           
            var result = await firebaseClient
              .Child("Leads")
              .OnceAsync<FirebaseLeadData>();

            foreach (var timestamp in result.Reverse())
            {
                var lead = new FireBaseLead();
                lead.date = timestamp.Object.TimestampUtc;
                lead.mobile = timestamp.Object.mobile;
                lead.name = timestamp.Object.name;
                lead.email = timestamp.Object.email;
                lead.projectName = timestamp.Object.projectName;
                lead.keyReference = timestamp.Key;
                Leads.Add(lead);
               
            }

            return Leads;
        }

        public async Task<ActionResult> SaveNewLeadsToRealTimeDB(LeadRequest LeadRequest)
        {
            DateTime gmtServerTime = DateTime.UtcNow;
            gmtServerTime = gmtServerTime.AddHours(5);
            gmtServerTime = gmtServerTime.AddMinutes(30);
            var currentLoginTime = gmtServerTime.ToString("MM/dd/yyyy HH:mm:ss");

            var firebaseLeadData = new FirebaseLeadData()
            {
                name = LeadRequest.name,
                mobile = LeadRequest.mobile,
                email = LeadRequest.email,
                TimestampUtc = currentLoginTime,
                projectName = LeadRequest.projectName == "" ? "NIRALA" : LeadRequest.projectName
            };
            var firebaseClient = new FirebaseClient("https://niralaestate-538ca-default-rtdb.firebaseio.com/");
            var result = await firebaseClient
              //.Child("Leads/" + todaysDate)
              .Child("Leads/")
              .PostAsync(firebaseLeadData);

            return new OkResult();
        }

        public async Task<FireBaseLead> GetLeadByReference(string KeyReference)
        {
            var firebaseClient = new FirebaseClient("https://niralaestate-538ca-default-rtdb.firebaseio.com/");
            var lead = new FireBaseLead();
            var result = await firebaseClient
              .Child("Leads")            
              .OnceAsync<FirebaseLeadData>();

            foreach (var timestamp in result)
            {
                if (timestamp.Key == KeyReference)
                {
                    lead.date = timestamp.Object.TimestampUtc;
                    lead.mobile = timestamp.Object.mobile;
                    lead.name = timestamp.Object.name;
                    lead.email = timestamp.Object.email;
                    lead.projectName = timestamp.Object.projectName;
                    lead.keyReference = timestamp.Key;
                    break;
                }

            }

            return lead;
        }

        public async Task<List<FCMTokenData>> GetSubscribedDevices()
        {
            var firebaseClient = new FirebaseClient("https://niralaestate-538ca-default-rtdb.firebaseio.com/");
            var tokensList = new List<FCMTokenData>();

            var result = await firebaseClient
              .Child("SubscribedDevices")
              .OnceAsync<FCMTokenData>();

            foreach (var timestamp in result)
            {
                var tokendata = new FCMTokenData();
                tokendata.deviceToken = timestamp.Object.deviceToken;
                tokendata.tokenDate = timestamp.Object.tokenDate;
                tokensList.Add(tokendata);
            }

            return tokensList;
        }

    }
}
